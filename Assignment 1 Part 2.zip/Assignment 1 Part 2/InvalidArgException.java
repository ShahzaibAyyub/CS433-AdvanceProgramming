public class InvalidArgException extends Exception {

    public InvalidArgException() {}
    public InvalidArgException(String message) { super(message);
    System.out.println(message);}
    public InvalidArgException(String message, Throwable cause) {super(message, cause);}
    public InvalidArgException(Throwable cause) {super(cause);}
    public InvalidArgException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {super(message, cause, enableSuppression, writableStackTrace); }
}
