import java.io.IOException;
import java.util.StringTokenizer;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;

/* Shahzaib Ayyub  17-0251
     -->  Code has been designed with the help of examples studied of string tokenizer and String java classes from following websites:
       1) https://www.tutorialspoint.com/java/util/java_util_stringtokenizer.htm#targetText=The%20java.util.StringTokenizer%20class,%2C%20numbers%2C%20and%20quoted%20strings.
       2) https://www.codota.com/code/java/classes/java.util.StringTokenizer
       3) https://www.geeksforgeeks.org/string-class-in-java/
       4) https://beginnersbook.com/2013/12/java-string-split-method-example/
       5) https://www.geeksforgeeks.org/throw-throws-java/
       6) https://www.tutorialspoint.com/java/java_exceptions.htm
       7) https://www.geeksforgeeks.org/file-handling-java-using-filewriter-filereader/
*/

public class Convert {
    public static void main(String[] args) throws IOException, InvalidArgException {

        String argStr = "";                        // putting arguments in a single string
        for (String arg : args) {
            argStr += arg;
            argStr += " ";
        }

        FileWriter convertFile = new FileWriter("Convert.txt");          //  open new text file for writing.

        String[] splitStr = argStr.split("]");                              // splitting string to seperate command.

        try { if (splitStr[1].length() == 0 || splitStr[1].equals(" "))
                throw new InvalidArgException("Exception: Please Enter a String after Command to be processed.");
        } catch (ArrayIndexOutOfBoundsException e) {System.out.println("Exception: Valid Switch not found (Missing ']')!");}                                                                     // throw exception if no sentence string is entered.

        String[] command = splitStr[0].split("");                          // splitting command string to check for condition
        String c1="[", c2="-", c3="]";

        if (command[2].equals("u") && command[0].equals(c1) && command[1].equals(c2)) {
                                                                                 // check splitted command for lower case condition
            if (splitStr[0].length()>4)
                throw new InvalidArgException("Exception: No Replace String required for this switch!");
                                                                                 // throw exception if unnecessary replace string entered
            String[] sentence = splitStr[1].split("");

            for (String str : sentence) {
                if (str.equals(command[3])) convertFile.write(str.toUpperCase());
                else convertFile.write(str);
            }
            convertFile.close();
        }

        else if (command[2].equals("o") && command[0].equals(c1) && command[1].equals(c2)) {   //  check splitted command for condition 2 (replace word condition)

            String replaceWord = "";                                             //  get replace word needed for condition 2

            for (String str : command) replaceWord += str;

            try {
                String replaceWordFinal = replaceWord.substring(5);              //   replace word without commands condition
                String rWordFinal = ", " + replaceWordFinal + ", ";              //  fulfilling replace word given in pdf

                String[] sentence = splitStr[1].split(" ");               //  storing second spitted half in sentence

                for (String str : sentence) {
                    String[] firstLetter = str.split("");                 //  Split for first letter
                    if (firstLetter[0].equals(command[3]) || firstLetter[0].toUpperCase().equals(command[3]) || firstLetter[0].equals(command[3].toUpperCase()))
                        convertFile.write(str + rWordFinal);                 //  check for first letter and command letter
                    else convertFile.write(str + " ");
                }
                convertFile.close();
            }
            catch (StringIndexOutOfBoundsException e) { System.out.println("Exception: Please Enter a String, in Command, to be Replaced!"); }
                                                                                        // throw exception for no replace string entered in condition 2
            catch (ArrayIndexOutOfBoundsException e) { System.out.println("Exception: Valid Switch not found (Missing ']')!");}
                                                                                         // throw exception for invalid Switch.
        }
        else throw new InvalidArgException("Exception: Please Enter a VALID Switch!");   // throw exception for invalid switch.


        FileReader convertFileRead = null;                                               // Read file
        try { convertFileRead = new FileReader("Convert.txt"); }
        catch (FileNotFoundException e) {System.out.println("Exception: File not found!");}

        int character;
        while ((character = convertFileRead.read()) != -1) System.out.print((char) character);
        convertFileRead.close();
    }
}
