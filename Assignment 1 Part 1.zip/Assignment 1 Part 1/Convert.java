import java.util.StringTokenizer;

/* Shahzaib Ayyub  17-0251
     -->  Code has been designed with the help of examples studied of string tokenizer and String java classes from following websites:
       1) https://www.tutorialspoint.com/java/util/java_util_stringtokenizer.htm#targetText=The%20java.util.StringTokenizer%20class,%2C%20numbers%2C%20and%20quoted%20strings.
       2) https://www.codota.com/code/java/classes/java.util.StringTokenizer
       3) https://www.geeksforgeeks.org/string-class-in-java/
       4) https://beginnersbook.com/2013/12/java-string-split-method-example/
*/

public class Convert {
    public static void main(String[] args) {

        String argStr = "";                        // putting arguments in a single string
        for (String arg : args){
            argStr += arg;
            argStr += " ";
        }

        String [] splitStr = argStr.split("]");                        // splitting string to seperate command

        String [] command = splitStr[0].split("");                     // splitting command string to check for condition

        if (command[2].equals("u")) {                                        // check splitted command for lower case condition
            String [] sentence = splitStr[1].split("");
            for (String str : sentence){
                if (str.equals(command[3])) System.out.print(str.toUpperCase());
                else System.out.print(str);
            }
        }

        else if (command[2].equals("o")) {                                   //  check splitted command for condition 2 (replace word condition)
            String replaceWord="";                                           //  get replace word needed for condition 2
            for (String str : command) replaceWord += str;

            String replaceWordFinal= replaceWord.substring(5);               //   replace word without commands condition
            String rWordFinal= ", " + replaceWordFinal +", ";                 //  fulfilling replace word given in pdf

            String [] sentence = splitStr[1].split(" ");              //   storing second spitted half in sentence

            for(String str:sentence ) {
                String [] firstLetter = str.split("");                 //  Split for first letter
                if (firstLetter[0].equals(command[3]) || firstLetter[0].toUpperCase().equals(command[3]))
                    System.out.print(str + rWordFinal);                       //     check for first letter and command letter
                else System.out.print(str + " ");
            }
        }
        else System.out.println("Invalid command Entered.");
    }
}
